import React, {useContext, useState} from 'react';
import {Context} from "../index";
import {useAuthState} from "react-firebase-hooks/auth";
import {Avatar, Button, Container, Grid} from "@material-ui/core";
import TextField from "@material-ui/core/TextField";
import {useCollectionData} from "react-firebase-hooks/firestore";
import Loader from "./Loader";
import firebase from "firebase";
import './components.css';


const Chat = () => {
    const {auth, firestore} = useContext(Context)
    const [user] = useAuthState(auth)
    const [value, setValue] = useState('')
    const [messages, loading] = useCollectionData(
        firestore.collection('messages').orderBy('createdAt')
    )

    const sendMessage = async () => {
        firestore.collection('messages').add({
            uid: user.uid,
            displayName: user.displayName,
            photoURL: user.photoURL,
            text: value,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        })
        setValue('')
    }

    if (loading) {
        return <Loader/>
    }

    return (
        <Container >
            
            <Grid container
                  justify={"center"}
                  style={{height: window.innerHeight - 50, marginTop: 20}}>
                    
                    
                <div className='chat' style={{width: '40%', height: '70vh', overflowY: 'auto'}}>
                    
                    {messages.map(message =>
                        <div className='messages' style={{
                            margin: 15,
                            marginLeft: user.uid === message.uid ? 'auto' : '10px',
                            width: 'fit-content',
                            padding: 5,
                        }}>                         

                        
                            <Grid container>
                                <Avatar src={message.photoURL} style={{width:30, height:30}}/>
                                <div className='text'>{message.displayName}</div>
                            </Grid>
                            <div className='text'>{message.text}</div>
                            
                        </div>                   
                    )}
                </div>

                <Grid
                    container
                    direction={"column"}
                    alignItems={"center"}
                    
                >
                    
                    <TextField
                        className='textField'                       
                        rowsMax={2}
                        variant={"outlined"}
                        value={value}
                        onChange={e => setValue(e.target.value)} 
                        style={{width: '500', height: '50'}}
                    /> 
                                      
                </Grid>
                <button className='button-36'  onClick={sendMessage} variant={"contained"}>Send</button>

                
                
            </Grid>     
        </Container>
        
    );
};

export default Chat;
