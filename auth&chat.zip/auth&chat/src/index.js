import React, {createContext} from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import firebase from "firebase";
import 'firebase/firestore'
import 'firebase/auth'


firebase.initializeApp({
        apiKey: "AIzaSyDChTiJepVW4M-Wl5ofQFhB4QLh2XRLUUs",
        authDomain: "auth-and-chat.firebaseapp.com",
        projectId: "auth-and-chat",
        storageBucket: "auth-and-chat.appspot.com",
        messagingSenderId: "911226583414",
        appId: "1:911226583414:web:75ed30ccba57a0e79f6257",
        measurementId: "G-2Q59JYB45H"
    }
);

export const Context = createContext(null)

const auth = firebase.auth()
const firestore = firebase.firestore()


ReactDOM.render(
    <Context.Provider value={{
        firebase,
        auth,
        firestore
    }}>
        <App />
    </Context.Provider>,
  document.getElementById('root')
);

